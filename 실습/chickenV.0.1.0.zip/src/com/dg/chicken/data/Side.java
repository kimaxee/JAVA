package com.dg.chicken.data;

public class Side {
	private String name;

	public Side(String name) {
		this.name = name;
	}

	public void info() {
		System.out.println(name);
	}
}
