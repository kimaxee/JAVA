package com.dg.chicken.data;

public class Drink {
	private String name;

	public Drink(String name) {
		this.name = name;
	}

	public void info() {
		System.out.println(name);
	}
}
