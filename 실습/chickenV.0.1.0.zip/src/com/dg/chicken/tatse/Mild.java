package com.dg.chicken.tatse;

public class Mild {

}
